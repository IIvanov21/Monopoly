#include "MonopolyManager.h"


const int defaultPropertyType = 1;

class PropertySquares : public MonopolyManager
{
public:
	void LoadPropertyInformation();
	void DisplayInformation();
	PropertySquares();
private:
	int squareNumber;
	int squareType;
	string fileName;
	string specialSquareNameElement;
	string firstPartOfPropertyName;
	string secondPartOfPropertyName;
	unique_ptr<PropertyStructure>loadPropertyInformation;
	vector <unique_ptr<PropertyStructure>>propertyList;
};