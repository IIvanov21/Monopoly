#pragma once  
#include <memory>
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <string>
using namespace std;


class MonopolyManager
{
private:
	 int startBalance;
	 int startPosition;
public:
	void gameStart();
	//void ChangeBalance(int balanceIn);
	//int GetBalance();
	int Random();

	enum SquareType { Normal, Special };

	struct PropertyStructure
	{
		string propertyName;
		string ownershipStatus;
		int cost;
		int rent;
		int group;
		int propertyNumber;
		SquareType type;
	};

	struct PlayerStructure
	{
		string name;
		int balance;
		int playerPosition;
	};
};
