#include "MonopolyManager.h"
#include "PropertySquares.h"

PropertySquares::PropertySquares()
{
	squareNumber = 0;
	squareType = 0;
	fileName = "Monopoly.txt";
}

void PropertySquares::LoadPropertyInformation()
{
	fstream propertyInfomation(fileName);
	string line;
	if (propertyInfomation.is_open())
	{
		while (!propertyInfomation.eof())
		{
			loadPropertyInformation.reset(new PropertyStructure);
			getline(propertyInfomation, line);
			stringstream line_stream(line);
			line_stream >> squareType;
			if (squareType > defaultPropertyType)
			{
				loadPropertyInformation->type = Special;
				loadPropertyInformation->group = squareType;
				while (!line_stream.eof())
				{
					line_stream >> specialSquareNameElement;
					loadPropertyInformation->propertyName += specialSquareNameElement + " ";
				}
				propertyList.push_back(move(loadPropertyInformation));
			}
			else if (squareType == defaultPropertyType)
			{
				loadPropertyInformation->type = Normal;
				line_stream >> firstPartOfPropertyName;
				line_stream >> secondPartOfPropertyName;
				loadPropertyInformation->propertyName = firstPartOfPropertyName + " " + secondPartOfPropertyName;
				line_stream >> loadPropertyInformation->cost;
				line_stream >> loadPropertyInformation->rent;
				line_stream >> loadPropertyInformation->group;
				squareNumber++;
				loadPropertyInformation->propertyNumber=squareNumber;
				loadPropertyInformation->ownershipStatus = "None";
				propertyList.push_back(move(loadPropertyInformation));
			}

		}
		propertyInfomation.close();
	}
	else cout << "File not open!Closing game..." << endl;
}

void PropertySquares::DisplayInformation()
{
	for (auto it = propertyList.begin(); it != propertyList.end(); it++)
	{
		cout << (*it)->propertyName << " " << (*it)->cost << " " << (*it)->rent << " "
			<< (*it)->group<<" "<<(*it)->propertyNumber<<endl;
	}
}